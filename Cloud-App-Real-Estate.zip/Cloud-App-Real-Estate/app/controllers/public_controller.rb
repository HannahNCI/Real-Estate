class PublicController < ApplicationController
  def main
  end
end
