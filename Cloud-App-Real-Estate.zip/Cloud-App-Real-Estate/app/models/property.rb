class Property < ApplicationRecord
end
